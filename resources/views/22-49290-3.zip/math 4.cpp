#include<iostream>
#include<cmath>

using namespace std;

int main(){
//product seleting
double total,product_value;

cout<<"enter your serial number";
cin>> product number;

if (product_number== 1){

product_value==(fioat)200.75;
}

else if (product_number==2){

    product_value==(float)345.50;
}

else if (product_number==3){

    product_value==(float)775.75

}

else if (product_number==4){

    product_value==(float)400.35;

}

else if (product_number==5){

    product_value==(float)1200,75;
}
else{

    cout<<"something error! please select the correct";
}
//quantity calculation


cout<<"how much quantity of this do you want ?";
cin>>quantity;


total=quantity * product_value;
cout<<"your totalretail price is"<<total;
return 0;
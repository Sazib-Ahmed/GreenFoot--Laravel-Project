#include<iostream>
#include<cmath>

using namespace std;

int main(){

int a,b,integer;

cout<<"enter the reminder"<<endl;
cin>> a;
cout<<"enter the reminder";
cin>> b;
reminder=a%2;
reminder=b%2;
if (reminder==0){

cout<<"the number is even"<<endl;
}

else

cout<<"the number is odd"<<endl;

return 0;



}
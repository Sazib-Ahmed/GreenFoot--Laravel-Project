#include<iostream>
#include<cmath>

using namespace std;

int main(){
double bmi,m,h;

cout<<"inter your weight"<<endl;
cin>> m;
cout<<"enter your height"<<endl;
cin>>h;

bmi=m/pow(h,2);
 cout<<"here is your bmi";
 return 0;





} 